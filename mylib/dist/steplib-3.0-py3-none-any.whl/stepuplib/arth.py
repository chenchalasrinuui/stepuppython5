def sum(n1,n2,n3):
    print(n1+n2+n3)

def sub(n1,n2):
    print(n1-n2)