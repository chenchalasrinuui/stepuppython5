name="Sachin"

def getName(name):
    print('Hey this is {}'.format(name))

class Student:
    name="s1"
    marks=300
    def getStdInfo(self):
        print('my name is {}, marks are {}'.format(self.name,self.marks))
