def sum(n1,n2,n3):
    print(n1+n2+n3)

