name='Dhoni'
def getName(name):
    print('my name is {}'.format(name))
